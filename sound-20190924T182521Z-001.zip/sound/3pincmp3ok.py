import RPi.GPIO as GPIO
import picamera
import time
var = 1
while var >0 :
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(23,GPIO.OUT)
    GPIO.setwarnings(False)
    time.sleep(0.000002)
    GPIO.output(23,1)
    time.sleep(0.000005)
    GPIO.output(23,0)
    GPIO.setup(23,GPIO.IN)
    while GPIO.input(23)==0:
        starttime=time.time()
    while GPIO.input(23)==1:
        endtime=time.time()
    print('measuring')
    duration=endtime-starttime
    distance=duration*34000/2
    print distance
    if distance < 20:
        with picamera.PiCamera() as camera:
            camera.resolution =(1080,960)
            camera.start_preview()
            from pygame import mixer
            mixer.init()
            mixer.music.load('t.mp3')
            mixer.music.play()
            time.sleep(5)
        var += 1
