amixer cset numid=3 0  hdmi first
amixer cset numid=3 1 3.5mm out
amixer cset numid=3 2  hmdi out
