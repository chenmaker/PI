import RPi.GPIO as GPIO
import time
pingPIN = 23
GPIO.setmode(GPIO.BCM)
#GPIO.setup(pingPIN,GPIO.OUT)
GPIO.setwarnings(False)
def send_pingPIN():
    GPIO.output(pimgPIN,True)
    time.sleep(0.001)
    GPIO.output(pingPIN,False)
def wait_for_pingPIN(value,timeout):
    count=timeout
    while GPIO.input(pingPIN)!=value and count >0:
        count=count-1
def get_distance():
    send_pingPIN_pulse()
    wait_for_pingPIN(True,5000)
    start=time.time()
    wait_for_pingPIN(False,5000)
    finish=time.time()
    pluse_len=finish-start
    distance_cm=pulse_len*340*1000/2
    distance_in=distance_cm/2.5
    return(distance_cm,distance_in)
while True:
    print("cm=%f\tinches=%f" % get_distance())
    time.sleep(1)
