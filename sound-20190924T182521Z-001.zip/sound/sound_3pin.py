#SIG->pin16
import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setup(23,GPIO.OUT)
GPIO.setwarnings(False)
time.sleep(0.000002)
GPIO.output(23,1)
time.sleep(0.000005)
GPIO.output(23,0)
GPIO.setup(23,GPIO.IN)
while GPIO.input(23)==0:
    starttime=time.time()
while GPIO.input(23)==1:
    endtime=time.time()
print('measuring')
duration=endtime-starttime
distance=duration*34000/2
print distance
