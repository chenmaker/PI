import picamera
import time
with picamera.PiCamera() as camera:
    camera.resolution =(1024,768)
    camera.start_preview()
    time.sleep(10)
    camera.start_recording('video.h264')
    camera.wait_recording(10)
    camera.stop_recording()
