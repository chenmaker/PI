omxplayer -p -o hdmi /home/pi/Desktop/camera/t.h264 

   
    
