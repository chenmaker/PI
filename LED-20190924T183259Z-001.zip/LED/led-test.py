import RPi.GPIO as GPIO
import time
r = [3,5,7,11,12,13,15,16,18,19,21,22,23,24,26,29,31,32,33,35,36,37,38,40]
    #0,1,2,3,4,5,6,7,8,9
GPIO.setmode(GPIO.BOARD)
x=-1
while x < 23:
        print('x1='+str(x))
        GPIO.setup(r[x],GPIO.OUT)#r[0]=3 r[1]=5
        x+=1
        print('x='+str(x))
t=1
while t > 0:
    GPIO.output(r[0],GPIO.HIGH)
    GPIO.output(5,GPIO.LOW)
    time.sleep(0.1)
    GPIO.output(r[0],GPIO.LOW)
    GPIO.output(5,GPIO.HIGH)
    time.sleep(0.1)
    #t += 1
    print('t='+str(t))
#GPIO.cleanup()



