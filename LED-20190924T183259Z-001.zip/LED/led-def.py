# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
import time
r = [3,5,7,11,12,13,15,16,18,19,21,22,23,24,26,29,31,32,33,35,36,37,38,40]
#    0,1,2,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10,11,12,13,14,15,16,17,18,19,20,21,22,23
#led_pin = 17
#這個GPIO.BOARD 選項是指定在電路版上接脚的號碼
#這個GPIO.BCM 選項是指定GPIO後面的號碼
#GPIO.setmode(GPIO.BCM)
GPIO.setmode(GPIO.BOARD)
x=0
while x < 24:
        GPIO.setup(r[x],GPIO.OUT)
        x+=1
        print('x='+str(x))
c=1
def LED(n):
    GPIO.output(n,GPIO.HIGH)
    time.sleep(1)
    GPIO.output(n,GPIO.LOW)
def LED1(m,t):
    y=0
    pwm_led = GPIO.PWM(m,100)
    pwm_led.start(100)
    print('t='+str(t))
    while t>0:
        pwm_led.ChangeDutyCycle(int(t))
        if (t==1 and y==1):
            y=0
        elif(t <=100 and y==1 ):
            t-=3
        elif t==100:
            y=1
        elif(t <=100 and y==0 ):
            t+=3
        return t
while c>0:
        LED(r[0])
        LED1(r[1],1)

