import RPi.GPIO as GPIO
r = [3,5,7,11,12,13,15,16,18,19,21,22,23,24,26,29,31,32,33,35,36,37,38,40]
led_pin = 17
#這個GPIO.BOARD 選項是指定在電路版上接脚的號碼
#這個GPIO.BCM 選項是指定GPIO後面的號碼
GPIO.setmode(GPIO.BCM)
#GPIO.setmode(GPIO.BOARD)
GPIO.setup(led_pin,GPIO.OUT)
pwm_led = GPIO.PWM(led_pin,500)
pwm_led.start(100)
t=1
y=0
while t>0:
    #duty = int(t)
    pwm_led.ChangeDutyCycle(int(t))
    print('t='+str(t))
    if (t==1 and y==1):
        y=0
    elif (t <=100 and y==1 ):
        t-=3
    elif t==100:
        y=1
    elif(t <=100 and y==0 ):
        t+=3
