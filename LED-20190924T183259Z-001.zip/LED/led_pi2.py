from gpiozero import LED
led=LED(17)
led.on()
led.off()
