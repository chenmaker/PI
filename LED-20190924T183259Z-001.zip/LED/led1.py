import RPi.GPIO as GPIO
led_pin = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(led_pin,GPIO.OUT)
pwm_led = GPIO.PWM(led_pin,500)
pwm_led.start(100)
t=1
y=0
while t>0:
    #duty = int(t)
    #pwm_led.ChangeDutyCycle(duty)
    pwm_led.ChangeDutyCycle(int(t))
    print('t='+str(t))
    if (t==1 and y==1):
        y=0
    elif (t <=100 and y==1 ):
        t-=3
    elif t==100:
        y=1
    elif(t <=100 and y==0 ):
        t+=3
