#!/usr/bin/python
import sys
import Adafruit_DHT
import I2C_LCD_driver
from time import *
mylcd = I2C_LCD_driver.lcd()
while True:
    humidity, temperature = Adafruit_DHT.read_retry(11, 4)
    
    mylcd.lcd_display_string("Temp: %d C" % temperature,0,0)
    mylcd.lcd_display_string("Humidity: %d %%" % humidity,1,0)
    
