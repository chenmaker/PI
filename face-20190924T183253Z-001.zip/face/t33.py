from picamera.array import PiRGBArray
from picamera import PiCamera
import picamera
import time
import cv2
cascPath = "/home/pi/opencv-3.3.0/data/haarcascades/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)
camera = PiCamera()
camera.resolution =(640,640)
camera.framerate=32
rawCapture = PiRGBArray(camera,size=(640,640))
time.sleep(0.5)
for frame in camera.capture_continuous(rawCapture,format="bgr",use_video_port=True):
    image = frame.array
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.3,
        minNeighbors=5,
        minSize=(10,10),
        flags=cv2.CASCADE_SCALE_IMAGE
        )
    if len(faces)>=1:
        print ("Found {0} faces!".format(len(faces)))
        time.sleep(0.2)
        for (x, y, w, h) in faces:
            cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.imshow("Frame", image)
            rawCapture.truncate(0)
            if cv2.waitKey(1) & 0xFF == ord("a"):#tow keyboard
                break
    elif len(faces)==0:
        time.sleep(0.2)
        print ('no face')
        cv2.imshow("Frame", image)
        rawCapture.truncate(0)
        if cv2.waitKey(1) & 0xFF == ord("a"):#tow keyboard
            break
camera.close()
cv2.destroyAllWindows()

        
