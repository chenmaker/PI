import cv2 
import sys
import numpy as np
imagePath = "family3.jpg"
#imagePath = "abba.png"
#imagePath = "graduation.jpg"
#imagePath = "ABBA.jpg"
cascPath = "/home/pi/opencv-3.3.0/data/haarcascades/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)
image = cv2.imread(imagePath)
cv2.imshow("Normal", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
faces = faceCascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,#abba.png-->5 graduation.jpg-->5  family3_.png-->20    
    minSize=(30,30),
    flags=cv2.CASCADE_SCALE_IMAGE
    )
print ("Found {0} faces!".format(len(faces)))
for (x, y, w, h) in faces:
    cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

cv2.imshow("image", image)
cv2.waitKey(0)
