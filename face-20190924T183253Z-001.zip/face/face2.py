import cv2 
import sys
import time
import numpy as np
imagePath = ["family3.jpg","graduation.jpg","ABBA.jpg"]
cascPath = "/home/pi/opencv-3.3.0/data/haarcascades/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)
t=0
image = ["image","image1","image2"]
while t < 3:
    image[t] = cv2.imread(imagePath[t])
    gray = cv2.cvtColor(image[t], cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,#abba.png-->5 graduation.jpg-->5  family3_.png-->20    
        minSize=(30,30),
        flags=cv2.CASCADE_SCALE_IMAGE
        )
    print ("Found {0} faces!".format(len(faces)))
    for (x, y, w, h) in faces:
        cv2.rectangle(image[t], (x, y), (x+w, y+h), (0, 255, 0), 2)
    cv2.imshow("image", image[t])
    cv2.waitKey(1000)
    t+=1
time.sleep(1)    
if t==3:
    cv2.destroyWindow("image")


    
    
    
