import cv2
img=cv2.imread('abba.png')
t=img.size
print(t)