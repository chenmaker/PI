import cv2
cv2.destroyWindow("image")
