python face-cmd.py graduation.jpg 5 
python face-cmd.py ABBA.jpg 5 
python face-cmd.py family3.jpg 20 
